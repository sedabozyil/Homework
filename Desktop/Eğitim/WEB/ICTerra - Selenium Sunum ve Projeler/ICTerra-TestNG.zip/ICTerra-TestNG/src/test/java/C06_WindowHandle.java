import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.Set;

public class C06_WindowHandle {

    WebDriver driver;

    @BeforeClass
    public void setup(){
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");

        driver = new ChromeDriver(options);

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

    }

    @Test
    public void windowHandle(){
        driver.get("https://www.icterra.com/tr/");
        String icterraHandle = driver.getWindowHandle();
        System.out.println("Icterra sayfasının değeri : " + icterraHandle);

        driver.switchTo().newWindow(WindowType.WINDOW); // Yeni pencere açıyor.

        driver.get("https://www.eriklabs.io/");
        String eriklabsHandle = driver.getWindowHandle();
        System.out.println("Eriklabs sayfasının değeri :" + eriklabsHandle);

        Set<String> handleDegerler = driver.getWindowHandles();
        System.out.println(handleDegerler);

        driver.switchTo().newWindow(WindowType.TAB); // eriklabs sayfasının yanına yeni bir tab açıyor.
        driver.get("https://eriklab.com/");

        driver.switchTo().window(icterraHandle);
        Assert.assertEquals("https://www.icterra.com/tr/", driver.getCurrentUrl());

    }

    @AfterClass
    public void ending(){
        driver.quit();
    }
}
