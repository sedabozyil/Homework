import org.testng.annotations.Test;

public class C08_TestBaseKullanımı extends C07_TestBase{

    @Test
    public void urleGitme(){
        driver.get("https://www.icterra.com/tr/");
    }
}
