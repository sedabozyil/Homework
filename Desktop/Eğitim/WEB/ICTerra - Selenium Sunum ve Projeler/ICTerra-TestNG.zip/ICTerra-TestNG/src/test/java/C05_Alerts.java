import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.Duration;

public class C05_Alerts {

    static WebDriver driver;

    @BeforeClass
    public static void setup(){

        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");

        driver = new ChromeDriver(options);

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

        driver.get("https://the-internet.herokuapp.com/javascript_alerts");
    }

    @Test
    public void acceptAlert(){
        WebElement accept = driver.findElement(By.xpath("//button[@onclick='jsAlert()']"));
        accept.click();

        driver.switchTo().alert().accept();

        WebElement sonucYazisi = driver.findElement(By.xpath("//p[@id='result']"));
        Assert.assertEquals("You successfully clicked an alert", sonucYazisi.getText());
    }

    @Test
    public void dismissAlert(){
        WebElement dismiss = driver.findElement(By.xpath("//button[@onclick='jsConfirm()']"));
        dismiss.click();

        driver.switchTo().alert().dismiss();

        WebElement sonucYazisi = driver.findElement(By.xpath("//p[@id='result']"));
        Assert.assertEquals("You clicked: Cancel", sonucYazisi.getText());
    }

    @Test
    public void sendKeysAlert() throws InterruptedException {
        WebElement sendKeys = driver.findElement(By.xpath("//button[@onclick='jsPrompt()']"));
        sendKeys.click();

        Thread.sleep(3000);
        driver.switchTo().alert().sendKeys("Text");
        driver.switchTo().alert().accept();

        WebElement sonucYazisi = driver.findElement(By.xpath("//p[@id='result']"));
        Assert.assertEquals("You entered: Text", sonucYazisi.getText());
    }

    @AfterClass
    public void ending(){
        driver.quit();
    }
}
