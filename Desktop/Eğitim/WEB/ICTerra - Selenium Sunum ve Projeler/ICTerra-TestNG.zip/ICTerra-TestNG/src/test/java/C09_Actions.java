import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class C09_Actions extends C07_TestBase {

    @Test
    public void mouseActions() throws InterruptedException {

        driver.get("https://the-internet.herokuapp.com/drag_and_drop");

        WebElement aNesnesi = driver.findElement(By.id("column-a"));
        WebElement bNesnesi = driver.findElement(By.id("column-b"));

        Actions actions = new Actions(driver);
        actions.dragAndDrop(aNesnesi, bNesnesi).perform();
        Thread.sleep(5000);
    }

    @Test
    public void keyboardActions(){

        driver.get("https://www.teknosa.com/");
        WebElement searchBox = driver.findElement(By.xpath("//input[@id='search-input']"));

        Actions actions = new Actions(driver);

        actions.click(searchBox).
                keyDown(Keys.SHIFT).
                sendKeys("s").
                keyUp(Keys.SHIFT).
                sendKeys("amsung").
                keyDown(Keys.SHIFT).
                sendKeys("a").
                keyUp(Keys.SHIFT).
                sendKeys("71").
                sendKeys(Keys.ENTER).
                perform();

        WebElement sonucYazisi = driver.findElement(By.xpath("//h1[@class= 'plp-title']"));
        Assert.assertTrue(sonucYazisi.getText().contains("Samsung"), "Keyboard action hatalı");
    }
}
