import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;

public class C10_explicitWait extends C07_TestBase{

    @Test
    public void waits(){

        driver.get("https://the-internet.herokuapp.com/dynamic_controls");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        //Remove butonuna bas
        WebElement removeButton = driver.findElement(By.xpath("//button[contains (., 'Remove')]"));
        removeButton.click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()=\"It's gone!\"]")));
        WebElement itsGoneMessage = driver.findElement(By.xpath("//p[@id='message']"));
        Assert.assertTrue(itsGoneMessage.isDisplayed());

    }
}
