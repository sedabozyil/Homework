import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class C04_SoftAssertion {

    @Test
    public void softAssert(){
        int a = 10;
        int b = 20;
        int c = 30;

        SoftAssert softAssert = new SoftAssert();

        softAssert.assertEquals(a,b,"1. Test başarısızdır.");
        softAssert.assertTrue(b>a,"2. Test başarısızdır.");
        softAssert.assertTrue(c>a,"3. Test başarısızdır.");
        softAssert.assertTrue(a>b,"4. Test başarısızdır.");

        // assertAll demezsek class çalışır ve passed yazar, raporlama yapmaz kodlar çalışmış olur
        softAssert.assertAll();
        System.out.println("Eğer softassertlardan fail olan var ise bu satır çalışmaz.");
    }
}
