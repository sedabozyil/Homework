public class TeknosaSearch {
/*

    main fonk.String
    teknosa sayfasına git.
    Searche tıklayıp "tablet" yaz
    Sonuç yazısını kontrol et
    İlk ürüne tıkla ve sepete ekle
    sepete eklendiğini kontrol et

    */

}
