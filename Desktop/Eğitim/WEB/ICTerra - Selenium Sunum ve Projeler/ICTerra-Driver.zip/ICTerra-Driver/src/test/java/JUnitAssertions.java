import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.time.Duration;

public class JUnitAssertions {

    static WebDriver driver;

    @BeforeClass
    public static void setup(){
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");

        driver = new ChromeDriver(options);

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

        driver.get("https://www.icterra.com/tr/");
    }

    @Test
    public void urlTesti(){
        /*WebElement endüstriler = driver.findElement(By.xpath("//a[@href='/tr/#endustriler']//div//div[contains (., 'Endüstriler')]"));
        endüstriler.click();
*/
        WebElement telekomünikasyon = driver.findElement(By.xpath("(//p[contains (., 'TELEKOMÜNİKASYON')])/../.."));
        telekomünikasyon.click();

        Assert.assertEquals("https://www.icterra.com/tr/endustriler/telekomunikasyon/", driver.getCurrentUrl());

    }

    @Test
    public void titleTesti(){
        String actualTitle = driver.getTitle();
        System.out.println(actualTitle);

        Assert.assertTrue("Başlık içerisinde Information geçmemektedir.",actualTitle.contains("Information"));
        //Assert.assertTrue("Başlık içerisinde Information geçmemektedir.",actualTitle.contains("İnformation")); -- bu kod hata verecektir ve hata mesajını logta görecez.

      /*  if (actualTitle.contains("Information")){
            System.out.println("Title testi PASSED");
        }
        else {
            System.out.println("Title Testi FAILED");
        }*/
    }

    @AfterClass
    public static void ending(){
        driver.close();
    }
}
