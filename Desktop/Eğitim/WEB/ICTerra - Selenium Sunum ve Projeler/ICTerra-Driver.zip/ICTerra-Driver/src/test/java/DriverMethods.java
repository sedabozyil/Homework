import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.time.Duration;

public class DriverMethods {

    public static void main(String[] args) {

        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");

        WebDriver driver = new ChromeDriver(options);

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        //ICTerra sayfasına gidilir.
        driver.get("https://www.icterra.com/tr/");
        System.out.println("Icterra sayfasına gitti");

        //eriklabs sitesine gidilir.
        driver.get("https://www.eriklabs.io/");
        System.out.println("Eriklabs sayfasına gitti");

        //ICterra sayfasına geri dönülür.
        driver.navigate().back();
        System.out.println("Geri butonuna basıldı");

        //Eriklabs sitesine geri dönelim.
        driver.navigate().forward();
        System.out.println("İleri butonuna basıldı");

        //sayfayı re-fresh edelim.
        driver.navigate().refresh();
        System.out.println("Yenile butonuna basıldı");

        //sayfayı kapatalım
        driver.close();
    }
}
