import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.time.Duration;

public class JUnitAnnotations {

    static WebDriver driver;

    @BeforeClass
    public static void setup(){
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");

        driver = new ChromeDriver(options);

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

        driver.get("https://www.icterra.com/tr/");
    }

    @Test
    public void searchTesti(){
        // search butonuna basılır.
        WebElement searchButton = driver.findElement(By.xpath("//div[@class='taptap-search-button-wrapper']"));
        searchButton.click();

        //search alanına "siber güvenlik" kelimesi yazılır
        WebElement searchArea = driver.findElement(By.xpath("//input[@placeholder='Arama terimini gir']"));
        searchArea.click();
        searchArea.sendKeys("Siber Güvenlik" + Keys.ENTER);

        // Sonuçların listelendiği kontrol edilir.
        WebElement titleControl = driver.findElement(By.xpath("//div[@class='et_pb_module et_pb_text et_pb_text_1_tb_body  et_pb_text_align_left et_pb_bg_layout_light']//div[@class='et_pb_text_inner']"));
        String titleText = titleControl.getText();
        if(titleText.contains("Siber Güvenlik")){
            System.out.println("Search Testi PASSED");
        }
        else {
            System.out.println("Search Testi FAILED");
        }
    }

    @Test
    public void titleTesti(){
        String actualTitle = driver.getTitle();

        if (actualTitle.contains("Information")){
            System.out.println("Title testi PASSED");
        }
        else {
            System.out.println("Title Testi FAILED");
        }
    }

    @AfterClass
    public static void ending(){
        driver.close();
    }
}
